// Copyright (c) 2023, 4C Solutions and contributors
// For license information, please see license.txt

frappe.ui.form.on('Appointment Type', {
	// refresh: function(frm) {

	// }
});
