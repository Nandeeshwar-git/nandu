# Copyright (c) 2023, 4C Solutions and Contributors
# See license.txt

# import frappe
from frappe.tests.utils import FrappeTestCase


class TestCaseCentralSettings(FrappeTestCase):
	pass
