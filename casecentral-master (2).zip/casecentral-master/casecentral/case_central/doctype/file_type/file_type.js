// Copyright (c) 2022, 4C Solutions and contributors
// For license information, please see license.txt

frappe.ui.form.on('File Type', {
	// refresh: function(frm) {

	// }
});
