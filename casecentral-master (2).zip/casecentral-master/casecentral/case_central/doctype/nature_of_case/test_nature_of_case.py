# Copyright (c) 2024, 4C Solutions and Contributors
# See license.txt

# import frappe
from frappe.tests.utils import FrappeTestCase


class TestNatureofCase(FrappeTestCase):
	pass
