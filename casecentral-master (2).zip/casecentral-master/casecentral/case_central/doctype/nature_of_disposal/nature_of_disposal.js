// Copyright (c) 2024, 4C Solutions and contributors
// For license information, please see license.txt

frappe.ui.form.on('Nature of Disposal', {
	// refresh: function(frm) {

	// }
});
