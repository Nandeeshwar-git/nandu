from frappe import _

def get_data():
	return [
		{
			"module_name": "Case Central",
			"type": "module",
			"label": _("Case Central")
		}
	]
